package com.example.bluedoll.adapters;

public class InsertDollsAdapter {
}
