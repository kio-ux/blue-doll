package com.example.bluedoll.views;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bluedoll.R;

public class ModifyDollActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_doll);
    }
}